#include "coMut.h"
int main(int argc, char **argv, char **envp){
	shellbaslat(argc, argv,envp);
}
/*
GRUP --6--
G171210021
G171210024
G171210045
G171210084
G171210375
*/
