# coMut Linux Shell Uygulaması 2A

Grup Üyeleri :
Onur Osman Güle g171210021
Fatih Aslan g171210045
Taha Furkan Cansizoğlu g171210024
Fatih Enis Kaya g171210375
Orhun Özdemir g171210084

Visual Studio Code'da ve Windows Ubuntu Bash ile yazıldı.

Projedeki ayrıntılar :
echo prompt vs neredeyse bütün işlemler çalışıyor.
Parantezde bazen hata çıkabiliyor
Pipe işlemi 2'li pipeta çalışıyor ancak 3'lüde sorun çıkabiliyor.
